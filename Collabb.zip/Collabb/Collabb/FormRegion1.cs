﻿using Microsoft.Office.Interop.Outlook;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Office = Microsoft.Office.Core;
using Outlook = Microsoft.Office.Interop.Outlook;
using Microsoft.Exchange.WebServices;
using Microsoft.Exchange.WebServices.Data;

namespace Collabb
{
    partial class FormRegion1
    {
        #region Form Region Factory

        [Microsoft.Office.Tools.Outlook.FormRegionMessageClass(Microsoft.Office.Tools.Outlook.FormRegionMessageClassAttribute.Appointment)]
        [Microsoft.Office.Tools.Outlook.FormRegionMessageClass("IPM.Meeting")]
        [Microsoft.Office.Tools.Outlook.FormRegionName("Collabb.FormRegion1")]
        public partial class FormRegion1Factory
        {
            // Occurs before the form region is initialized.
            // To prevent the form region from appearing, set e.Cancel to true.
            // Use e.OutlookItem to get a reference to the current Outlook item.
            private void FormRegion1Factory_FormRegionInitializing(object sender, Microsoft.Office.Tools.Outlook.FormRegionInitializingEventArgs e)
            {
            }
        }

        #endregion

        // Occurs before the form region is displayed.
        // Use this.OutlookItem to get a reference to the current Outlook item.
        // Use this.OutlookFormRegion to get a reference to the form region.
        private void FormRegion1_FormRegionShowing(object sender, System.EventArgs e)
        {

            ExchangeService svc = new ExchangeService(ExchangeVersion.Exchange2010);
            svc.Credentials = new WebCredentials("giridharan.a@hcl.com", "Newuser5$");
            Uri uri = new Uri("https://outlook.office365.com/owa/HCL.COM/");
            svc.Url = uri;
            //svc.AutodiscoverUrl("arul.giridharan@ing.com.au", RedirectionUrlValidationCallback);

            GetSuggestedMeetingTimesAndFreeBusyInfo(svc);
        }

        static bool RedirectionUrlValidationCallback(String redirectionUrl)
        {
            bool redirectionValidated = false;
            if (redirectionUrl.Equals(
                "https://autodiscover-s.outlook.com/autodiscover/autodiscover.xml"))
                redirectionValidated = true;

            return redirectionValidated;
        }

        private void DemoAppointmentsInRange()
        {
            Application App = new Application();
            Outlook.Folder calFolder = (Outlook.Folder)App.Session.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderCalendar);
            DateTime start = DateTime.Now;
            DateTime end = start.AddDays(1);
            Outlook.Items rangeAppts = GetAppointmentsInRange(calFolder, start, end);
            if (rangeAppts != null)
            {

                foreach (Outlook.AppointmentItem appt in rangeAppts)
                {
                    listBox1.Items.Add("Subject: " + appt.Subject + " Start: " + appt.Start.ToString("g"));
                    //Debug.WriteLine("Subject: " + appt.Subject + " Start: " + appt.Start.ToString("g"));
                }
            }
        }

        private Outlook.Items GetAppointmentsInRange(Outlook.Folder folder, DateTime startTime, DateTime endTime)
        {
            string filter = "[Start] >= '"
                + startTime.ToString("g")
                + "' AND [End] <= '"
                + endTime.ToString("g") + "'";
            //Debug.WriteLine(filter);
            try
            {
                Outlook.Items calItems = folder.Items;
                calItems.IncludeRecurrences = true;
                calItems.Sort("[Start]", Type.Missing);
                Outlook.Items restrictItems = calItems.Restrict(filter);
                if (restrictItems.Count > 0)
                {
                    return restrictItems;
                }
                else
                {
                    return null;
                }
            }
            catch { return null; }
        }

        private static void GetSuggestedMeetingTimesAndFreeBusyInfo(ExchangeService service)
        {
            // Create a collection of attendees. 
            List<AttendeeInfo> attendees = new List<AttendeeInfo>();

            attendees.Add(new AttendeeInfo()
            {
                SmtpAddress = "arul.giridharan@ing.com.au",
                AttendeeType = MeetingAttendeeType.Organizer
            });

            attendees.Add(new AttendeeInfo()
            {
                SmtpAddress = "giridharan.a@hcl.com",
                AttendeeType = MeetingAttendeeType.Required
            });

            // Specify options to request free/busy information and suggested meeting times.
            AvailabilityOptions availabilityOptions = new AvailabilityOptions();
            availabilityOptions.GoodSuggestionThreshold = 49;
            availabilityOptions.MaximumNonWorkHoursSuggestionsPerDay = 0;
            availabilityOptions.MaximumSuggestionsPerDay = 2;
            // Note that 60 minutes is the default value for MeetingDuration, but setting it explicitly for demonstration purposes.
            availabilityOptions.MeetingDuration = 60;
            availabilityOptions.MinimumSuggestionQuality = SuggestionQuality.Good;
            availabilityOptions.DetailedSuggestionsWindow = new TimeWindow(DateTime.Now.AddDays(1), DateTime.Now.AddDays(2));
            availabilityOptions.RequestedFreeBusyView = FreeBusyViewType.FreeBusy;

            // Return free/busy information and a set of suggested meeting times. 
            // This method results in a GetUserAvailabilityRequest call to EWS.
            GetUserAvailabilityResults results = service.GetUserAvailability(attendees,
                                                                             availabilityOptions.DetailedSuggestionsWindow,
                                                                             AvailabilityData.FreeBusyAndSuggestions,
                                                                             availabilityOptions);
            // Display suggested meeting times. 
            Console.WriteLine("Availability for {0} and {1}", attendees[0].SmtpAddress, attendees[1].SmtpAddress);
            Console.WriteLine();

            foreach (Suggestion suggestion in results.Suggestions)
            {
                Console.WriteLine("Suggested date: {0}\n", suggestion.Date.ToShortDateString());
                Console.WriteLine("Suggested meeting times:\n");
                foreach (TimeSuggestion timeSuggestion in suggestion.TimeSuggestions)
                {
                    Console.WriteLine("\t{0} - {1}\n",
                                      timeSuggestion.MeetingTime.ToShortTimeString(),
                                      timeSuggestion.MeetingTime.Add(TimeSpan.FromMinutes(availabilityOptions.MeetingDuration)).ToShortTimeString());
                }
            }

            int i = 0;
            // Display free/busy times.
            foreach (AttendeeAvailability availability in results.AttendeesAvailability)
            {
                Console.WriteLine("Availability information for {0}:\n", attendees[i].SmtpAddress);
                foreach (CalendarEvent calEvent in availability.CalendarEvents)
                {
                    Console.WriteLine("\tBusy from {0} to {1} \n", calEvent.StartTime.ToString(), calEvent.EndTime.ToString());
                }
                i++;
            }
        }

        // Occurs when the form region is closed.
        // Use this.OutlookItem to get a reference to the current Outlook item.
        // Use this.OutlookFormRegion to get a reference to the form region.
        private void FormRegion1_FormRegionClosed(object sender, System.EventArgs e)
        {
        }
    }
}
